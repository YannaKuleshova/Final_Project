#########################
# Author: Kuleshova Yana
# Name_project: ToDo List
# Date: 16/12/2021
#########################


from programs.packeges import module_3
#from programs.packeges import module_4
from programs.packeges import module_5
from programs.packeges import module_6

menu_controller = module_3.menu_controller()

# Цикл выбора меню для ввода.
while True:
    print('''
    1. Show task
    2. Add task
    3. Change Priority
    4. Delete task
    5. Exit
    ''')
                
    try:
        put = int(input('Put what you want: 1 or 2 or 3 or 4 or 5: '))
        if put == 5:
            menu_controller(put)
            break
    except:
        print('Bad operation')
    else:
        if put in [1, 2, 3, 4]:
            menu_controller(put)
exit

# ----- Logging -----
import logging

# Формат вывода текста в лог-файле.
FORMAT = '%(name)s:\n%(levelname)s:\n%(asctime)s' 

logger = logging.getLogger(__name__)
# Запись данных в лог-файл.
handler = logging.FileHandler('D:/PYTHON/My_Projects__/ToDoList.log', mode = 'w')
handler.setLevel(logging.CRITICAL)

formatter = logging.Formatter(FORMAT)
handler.setFormatter(formatter)

logger.addHandler(handler)

logger.critical('CRITICAL message')
logger.error('ERROR message')
logger.warning('WARNING message')
logger.info('INFO message')
logger.debug('DEBUG message')


# ----- configparser -----

import configparser

config = configparser.ConfigParser()
# Формат записи в файл ini.
config['DEFAULT'] = {'host': 'localhost'}
config['tododb'] = {'name': 'tasks',
                    'user': 'root',
                    'password': 'password'}
config['redis'] = {'port': 6379,
                    'db': 0}
# Запись данных в файл ini.
with open('D:/PYTHON/My_Projects__/config_ToDo.ini', 'w') as configfile:
    config.write(configfile)


