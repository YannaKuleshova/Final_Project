# File "module_5.py"
# Path "D:\PYTHON\programs\packeges\"

#-------------JSON-------------
   
import json
import requests
from programs.packeges import module_1

Todo = module_1.Todo()
key_names = Todo.c.execute('''SELECT * FROM tasks;''')
key_widths = [10, 15, 10, 15]

def show_head():
    for (n, w) in zip(key_names, key_widths):
        print(n.ljust(w), end = '|  ')
    print()

# Функция печати "ничего"
def show_empty():
    for w in key_widths:
        print(' '.ljust(w), end = '|  ')
    print()

# Функция печати данных из файла.
def show_tasks(todo):
    for (n, w) in zip(key_names, key_widths):
        print(str(todo[n]).ljust(w), end = '|  ')
    print()

# Функция печати всего содержимого файла.
def show(json):
    # Отображение заголовка.
    show_head()
    # Если данные json в формате строк - вывод данных по умолчанию.
    if type(json) is list:
        for todo in json:
            show_tasks(todo)
    # Если данные json в формате словаря - вывод данных по json.
    elif type(json) is dict:
        if json:
            show_tasks(json)
        else:
            show_empty()

try:
    reply = requests.get('http://localhost:3000/todo')
except requests.RequestException:
    print("Communication error")
else:
    if reply.status_code == requests.codes.ok:
        show(reply.json())
    else:
        print("Server error")


if __name__ == "__ToDo__":
    pass