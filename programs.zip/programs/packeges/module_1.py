# File "module_1.py"
# Path "D:\PYTHON\programs\packeges\"

# ----- ToDo List -----

import sqlite3
from programs.packeges import module_4

NameExc = module_4.NameExc()
PriorExc = module_4.PriorExc()
IdExc = module_4.IdExc()

# Класс формирования ToDo List.
class Todo:
    # Функция инициализации класса.
    def __init__(self):
        self.conn = sqlite3.connect('D:/PYTHON/My_Projects__/todo.db')
        #self.conn = sqlite3.connect('todo.db')
        self.c = self.conn.cursor()
        self.create_task_table()

    # Функция создания таблицы задач в БД с колонками ID, NAME and PRIORITY.
    def create_task_table(self):
        self.c.execute('''CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            priority INTEGER NOT NULL
            ); ''')
    
    # Функция добавления задачи в БД.
    def add_task(self):
        # Ввод пользователем имени задачи для добавления.
        task_name = input('Enter task name: ')
        # Если ничего не введдено, сообщение об ошибке.
        if len(task_name) == 0 or task_name.isspace():
            raise NameExc
        # Переменная поиска имени задачи в таблице.
        res = self.find_task(task_name) 

        if res == None:
            pass
        else:
            # Если задача уже существует, то сообщение об ошибке.
            raise NameExc(mes='Already have!')

        # Ввод пользователем приоритета задачи.
        priority = int(input('Enter priority: '))
        # Если приоритет меньше 1, сообщение об ошибке.
        if priority < 1: 
            raise PriorExc

         # Создание записи задачи в БД.
        self.c.execute('''INSERT INTO tasks (name, priority) VALUE (?,?)''', (task_name, priority))
        self.conn.commit()

    # Функция поиска задачи в БД.
    def find_task(self, task_name):
        self.task_name = task_name
        find = False

        # Выборка в БД по всем полям.
        que = '''SELECT id, name, priority FROM tasks;'''
        rows = self.c.execute(que)

        # Поиск по всем строкам.
        for row in rows:
            # Если задача в БД найдена, возвращает задачу.
            if row[1] == self.task_name:
                find = True
                return row
        # Если задача в БД не найдена - возвращает ничего.
        if not find:
            return None
    
    # Функция изменения приоритета задачи в БД.
    def change_priority(self):
        # Ввод пользователем желаемого приоритета.
        priority = int(input('Enter preferable priority: '))
        if priority < 1:
            raise PriorExc
        # Ввод пользователем ID.
        numid = int(input('Enter id: '))
        if numid < 1:
            raise IdExc

        # Обновление записи задачи в БД.
        self.c.execute('''UPDATE tasks SET priority = ? WHERE id = ?;''', (priority, numid))
        self.conn.commit()

    # Функция удаления задачи.
    def delete_task(self):
        # Ввод пользователем ID задачи для удаления.
        numid = int(input('Enter Id which you want to delete: '))
        # Если ID меньше 1, выводит ошибку.
        if numid < 1: 
            raise IdExc
        # Удаление записи задачи в БД.
        self.c.execute('''DELETE FROM tasks WHERE id = ?''', (numid,))
        self.conn.commit()

    # Функция отображения всех задач.
    def show_task(self): 
        print("Сейчас покажу все задачи: ")
        print("ID  |  Task name  |  Priority")
        # Выборка задач в БД по всем полям.
        for row in self.c.execute('''SELECT * FROM tasks;'''):
            #self.conn.commit()
            print(row)

if __name__ == "__ToDo__":
    Todo()