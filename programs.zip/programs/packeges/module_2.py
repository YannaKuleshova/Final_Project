# File "module_2.py"
# Path "D:\PYTHON\programs\packeges\"

#-------------JSON-------------
   
import json
from programs.packeges import module_1

Todo = module_1.Todo()

class MyEncoder(json.JSONEncoder):
    def default(self, w):
        # Проверка подкласса на принадлежность классу.
        if isinstance(w, Todo.show_task):
            # Возвращает словарь.
            return w.__dict__
        else:
            raise TypeError(w.__class__.__name__ + 'is not JSON')

class MyDecoder(json.JSONDecoder):
    # Инициализация класса.
    def __init__(self): 
        json.JSONDecoder.__init__(self, object_hook = self.decode_who)

    def decode_who(self):
        with open("D:/PYTHON/My_Projects__/ToDo.json", "w") as wr_file:
            json.dumps(Todo.show_task, wr_file)
    
def json_show():
    json_str = json.dumps(MyEncoder.default)
    json.loads(json_str, cls = MyDecoder)    


if __name__ == "__ToDo__":
    Todo()