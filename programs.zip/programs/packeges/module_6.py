# File "module_6.py"
# Path "D:\PYTHON\programs\packeges\"

# ----- configparser -----

import configparser

def config_parser():
    config = configparser.ConfigParser()

    config['DEFAULT'] = {'host': 'localhost'}
    config['tododb'] = {'name': 'tasks',
                        'user': 'root',
                        'password': 'password'}
    config['redis'] = {'port': 6379,
                        'db': 0}

    with open('D:/PYTHON/My_Projects__/configToDo.ini', 'w') as configfile:
        config.write(configfile)

if __name__ == "__ToDo__":
        pass
