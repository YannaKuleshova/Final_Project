# File "module_3.py"
# Path "D:\PYTHON\programs\packeges\"

# ----- Выбор меню -----

from programs.packeges import module_1
from programs.packeges import module_4

NameExc = module_4.NameExc()
PriorExc = module_4.PriorExc()
IdExc = module_4.IdExc()
Todo = module_1.Todo()

# Функция создания меню для выбора действия пользователем.
def menu_controller (put = 0):

    # Если пользователь ввел 1.
    if put == 1:
    
    # Обработка ошибок для функции show_task service.
        try:
            Todo.show_task()
        except NameExc as e:
            print(e)
        except:
            print('Something goes badly!')
        else:
            print('All right!')
        finally:
            print('...')
    
    # Если пользователь ввел 2.
    elif put == 2:

    # Обработка ошибок для функции add task service.
        try:
            Todo.add_task()
        except NameExc as e:
            print(e)
        except PriorExc as e:
            print(e)
        except:
            print('Something goes bady :((')
        else:
            print('The task was added successfully')
        finally:
            print('...')
    
    # Если пользователь ввел 3.
    elif put == 3:

    # Обработка ошибок для функции update priority.
        try:
            Todo.change_priority()
        except PriorExc as e:
            print(e)
        except IdExc as e:
            print(e)
        except:
            print('Something goes badly!')
        else:
            print('The priority was update.')
        finally:
            print('...')

    # Если пользователь ввел 4.
    elif put == 4:

    # Обработка ошибок для функции delete task service.
        try:
            Todo.delete_task()
        except IdExc as e:
            print(e)
        except:
            print('Something goes badly!')
        else:
            print('The task was deleted successfully.')
        finally:
            print('...')

    # Если пользователь ввел 5 - выход из программы.
    elif put == 5:
        exit

    else:
        pass


    # Put menu.
    while True:
        print('''
        1. Show task
        2. Add task
        3. Change Priority
        4. Delete task
        5. Exit
        ''')
                    
        try:
            put = int(input('Put what you want: 1 or 2 or 3 or 4 or 5: '))
            if put == 5:
                menu_controller(put)
                break
        except:
            print('Bad operation')
        else:
            if put in [1, 2, 3, 4]:
                menu_controller(put)


    if __name__ == "__ToDo__":
        menu_controller()