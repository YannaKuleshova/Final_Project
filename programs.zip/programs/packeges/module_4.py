# File "module_4.py"
# Path "D:\PYTHON\programs\packeges\"

# ----- Exceptions -----


# Класс обарботки ошибок имени задачи.
from My_Projects__.ToDo_List import Todo


class NameExc(Exception):
    def __init__(self, head="TDTaskNameError", mess="Bad name!"):
       super().__init__(mess)
       self.head = head
       self.mess = mess

# Класс обарботки ошибок приоритета задачи.
class PriorExc(NameExc):
    def __init__(self, head="TDTaskPriorityError", mess="Bad priority!"):
        super().__init__(mess)
        self.head = head
        self.mess = mess

# Класс обарботки ошибок Id задачи.
class IdExc(PriorExc):
    def __init__(self, head="TDTaskIdError", mess="Bad Id!"):
        super().__init__(mess)
        self.head = head
        self.mess = mess

if __name__ == "__ToDo__":
    pass